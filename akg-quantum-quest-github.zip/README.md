# AKG Quantum Quest

Premium real-estate advisory website for AKG Quantum Quest.

## Pages

- `index.html` — main website
- `vmaks-laurel.html` — VMAKS Laurel project page

## GitHub Pages

This repository includes a GitHub Actions workflow at:

`.github/workflows/pages.yml`

After pushing to `main`:

1. Open **Settings → Pages** in the GitHub repository.
2. Set **Source** to **GitHub Actions**.
3. GitHub will deploy the site automatically on every push to `main`.

GitHub Pages documentation:
https://docs.github.com/en/pages/getting-started-with-github-pages

## Supabase

The enquiry forms use the existing AKG Quantum Quest Supabase project.

Project:
https://sbcfmibivdvcdortuptw.supabase.co

Only the browser-safe publishable key is used. Do not put a Supabase service-role/secret key in this repository.

## Before launch

Replace placeholder/illustrative project artwork with approved project photographs and verify live pricing, availability, RERA/project claims and contact details.

## Suggested repository name

`akg-quantum-quest`

If you want a user/organization site instead, use the repository naming convention:

`YOUR-GITHUB-USERNAME.github.io`
